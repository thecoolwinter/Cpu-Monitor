Modified version of Electron's sample CPU app. 

Good example of making a window that spawns on the tray and can hide and show on tray click.

Please copy and make it better <3 :)







icon by Vaadin